#!/bin/bash

repository="https://github.com/sahilm1992/COL761.git"
git clone "$repository"