# COL761
Data Mining
Assignments and projects.

IIT DELHII
